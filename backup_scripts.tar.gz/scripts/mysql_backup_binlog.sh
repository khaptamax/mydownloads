#!/bin/bash

# Configuration
BACKUP_DIR="/dbbackup/MySQL_TEST"
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_USER="backup"
BACKUP_PASS="F67#df62zer-hyU"
BINLOG_DIR="/var/lib/mysql"
RSYNC_OPTS="-avz"
BACKUP_LOG=$BACKUP_DIR/OSS_BINLOG/binlog_$DATE.log

echo "doing binlog backup at $(date +%Y%m%d_%H%M%S)" > $BACKUP_LOG
echo "FLUSH LOGS..." >> $BACKUP_LOG
mysql -u $BACKUP_USER -p$BACKUP_PASS -e "FLUSH BINARY LOGS;" >> $BACKUP_LOG 2>&1

echo ">> Synchronization with rsync..." >> $BACKUP_LOG
rsync $RSYNC_OPTS $BINLOG_DIR/mysql-bin.* $BACKUP_DIR/OSS_BINLOG/binlog >> $BACKUP_LOG 2>&1

echo "Binlog backup completed at $(date +%Y%m%d_%H%M%S)" >> $BACKUP_LOG
find $BACKUP_DIR/OSS_BINLOG -type f -name "*.log" -mtime +14 -exec rm -rf {} \;
