#!/bin/bash

# Configuration
BACKUP_DIR="/dbbackup/MySQL_TEST"
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_USER="backup"
BACKUP_PASS="F67#df62zer-hyU"
BACKUP_TYPE=$1

# Determine backup type
if [[ "FULL" == $BACKUP_TYPE ]]; then
   # Full backup
   BACKUP_LOG=$BACKUP_DIR/OSS_FULL/full_$DATE.log
   echo "doing full backup..." > $BACKUP_LOG
   xtrabackup --backup \
        --user=$BACKUP_USER \
        --password=$BACKUP_PASS \
        --parallel=8 \
        --target-dir=$BACKUP_DIR/OSS_FULL/full_$DATE >> $BACKUP_LOG 2>&1
   cp -p /var/lib/mysql/*.cnf $BACKUP_DIR/OSS_FULL/full_$DATE >> $BACKUP_LOG 2>&1
   rsync -avz /etc/my.cnf $BACKUP_DIR/OSS_CONFIG >> $BACKUP_LOG 2>&1
   rsync -avz /etc/my.cnf.d/mysql-server.cnf $BACKUP_DIR/OSS_CONFIG >> $BACKUP_LOG 2>&1
   echo "Full backup completed at $(date +%Y%m%d_%H%M%S)" >> $BACKUP_LOG 2>&1

   # Update latest full backup link
   rm -f $BACKUP_DIR/OSS_FULL/latest_full
   ln -sf $BACKUP_DIR/OSS_FULL/full_$DATE $BACKUP_DIR/OSS_FULL/latest_full
elif [[ "INCR" == $BACKUP_TYPE ]]; then
   # Incremental backup
   BACKUP_LOG=$BACKUP_DIR/OSS_INC/inc_$DATE.log
   echo "doing incremental backup..." > $BACKUP_LOG
   xtrabackup --backup \
        --user=$BACKUP_USER \
        --password=$BACKUP_PASS \
        --parallel=8 \
        --target-dir=$BACKUP_DIR/OSS_INC/inc_$DATE \
        --incremental-basedir=$BACKUP_DIR/OSS_FULL/latest_full >> $BACKUP_LOG 2>&1
   echo "Incremental backup completed at $(date +%Y%m%d_%H%M%S)" >> $BACKUP_LOG
else
   echo "Usage : mysql_backup.sh [FULL | INCR]"
   exit 1
fi

# Keep 14 days of backups
find $BACKUP_DIR/OSS_FULL -type d -name "full_*" -mtime +14 -exec rm -rf {} \;
find $BACKUP_DIR/OSS_INC -type d -name "inc_*" -mtime +14 -exec rm -rf {} \;
find $BACKUP_DIR/OSS_FULL -type f -name "*.log" -mtime +14 -exec rm -rf {} \;
find $BACKUP_DIR/OSS_INC -type f -name "*.log" -mtime +14 -exec rm -rf {} \;
